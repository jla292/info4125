// popup.js
document.addEventListener("DOMContentLoaded", async () => {
  // Load latest result (if user used the context menu already)
  const { lastResult } = await chrome.storage.local.get(["lastResult"]);
  if (lastResult) renderResult(lastResult);

  // Live update if a new result arrives while popup is open
  chrome.runtime.onMessage.addListener((msg) => {
    if (msg?.type === "RESULT_UPDATED" && msg.payload) {
      renderResult(msg.payload);
    }
  });

  // Optional: check whatever is currently selected (without right-click)
  const btn = document.getElementById("checkCurrentSelection");
  if (btn) {
    btn.addEventListener("click", async () => {
      const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
      if (!tab?.id) return;

      const [{ result: selectedText } = {}] = await chrome.scripting.executeScript({
        target: { tabId: tab.id },
        func: () => (window.getSelection && window.getSelection().toString()) || ""
      });

      if (selectedText && selectedText.trim()) {
        // Send to the content script for highlighting + model call
        chrome.tabs.sendMessage(tab.id, { type: "CHECK_TEXT", text: selectedText.trim() });
      } else {
        showMessage("Select some text on the page first.");
      }
    });
  }
});

function renderResult(r) {
  // Bar
  const indicator = document.getElementById("indicator");
  const verdictEl = document.getElementById("verdict");
  const snippetEl = document.getElementById("snippet");
  const pageTitle = document.getElementById("pageTitle");
  const pageUrl = document.getElementById("pageUrl");
  const sourceEl = document.getElementById("source");

  // Percent false (0..100)
  const percentFalse = Number(r?.percent_false ?? (r?.confidence_fake ?? 0) * 100);
  if (indicator && !Number.isNaN(percentFalse)) {
    indicator.style.width = Math.max(0, Math.min(100, Math.round(percentFalse))) + "%";
    indicator.classList.toggle("is-false", percentFalse >= 50);
    indicator.classList.toggle("is-true", percentFalse < 50);
  }

  if (verdictEl) verdictEl.textContent = r?.verdict_text || (percentFalse >= 50 ? "Likely False" : "Likely True");

  // Selected text
  const txt = (r?.input || "").toString();
  if (snippetEl) {
    snippetEl.textContent = txt.length > 280 ? txt.slice(0, 280) + "…" : txt || "—";
  }

  // Page meta
  if (pageTitle) pageTitle.textContent = r?.title ? `On: ${r.title}` : "";
  if (pageUrl) pageUrl.textContent = r?.url ? r.url : "";

  // Source (if available)
  if (sourceEl) {
    if (r?.primary_source?.source) {
      const s = r.primary_source;
      sourceEl.textContent = s.source + (s.count ? ` (seen ${s.count}×)` : "");
      sourceEl.title = s.best?.text || ""; // hover to see short_text if present
    } else {
      sourceEl.textContent = "N/A";
      sourceEl.title = "";
    }
  }
}

function showMessage(msg) {
  const el = document.getElementById("message");
  if (el) { el.textContent = msg; el.style.display = "block"; }
}
