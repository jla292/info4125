// content.js
// Highlights the user's selection, calls Flask, stores the result for the popup, and nudges the popup to open.

const API_URL = "http://127.0.0.1:5000/predict"; 

let lastSelectionRange = null;

// Track the last user selection so we can highlight exactly that text
document.addEventListener("mouseup", () => {
  const sel = window.getSelection();
  if (sel && sel.rangeCount > 0 && !sel.isCollapsed) {
    lastSelectionRange = sel.getRangeAt(0).cloneRange();
  }
});

chrome.runtime.onMessage.addListener(async (msg) => {
  if (msg?.type !== "CHECK_TEXT" || !msg.text) return;

  // Call backend
  let data;
  try {
    const res = await fetch(API_URL, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ text: msg.text })
    });
    data = await res.json();
  } catch (e) {
    data = { error: String(e) };
  }

  // Normalize result for both backend shapes
  const normalized = normalizeModelOutput(data, msg.text);

  // Highlight selection (soft red if fake, soft green if true)
  if (lastSelectionRange) {
    try {
      const mark = document.createElement("mark");
      mark.className = "cornell-misinfo-mark";
      mark.style.backgroundColor = normalized.predicted_label === 1 ? "rgba(255,0,0,0.35)" : "rgba(0,128,0,0.25)";
      mark.style.padding = "0 2px";
      lastSelectionRange.surroundContents(mark);
    } catch {
      // Selection spans nodes: wrap the extracted contents
      const wrapper = document.createElement("mark");
      wrapper.className = "cornell-misinfo-mark";
      wrapper.style.backgroundColor = normalized.predicted_label === 1 ? "rgba(255,0,0,0.35)" : "rgba(0,128,0,0.25)";
      const contents = lastSelectionRange.extractContents();
      wrapper.appendChild(contents);
      lastSelectionRange.insertNode(wrapper);
    }
  }

  // Save to storage for the popup
  await chrome.storage.local.set({ lastResult: normalized });

  // Optional toast
  showToast(`${normalized.verdict_text} — ${normalized.percent_false}% false`);

  // Ask background to open the popup (best-effort)
  chrome.runtime.sendMessage({ type: "RESULT_READY" });
});

/** Normalize either the simple baseline response or the verification-system response. */
function normalizeModelOutput(raw, inputText) {
  // Baseline backend (your Flask joblib model)
  if (typeof raw?.predicted_label !== "undefined") {
    const label = Number(raw.predicted_label);
    const confFake = clamp01(Number(raw.confidence_fake ?? 0));
    const confTrue = clamp01(Number(raw.confidence_true ?? (1 - confFake)));

    return {
      input: inputText,
      predicted_label: label, // 1 = fake, 0 = true
      confidence_true: confTrue,
      confidence_fake: confFake,
      percent_false: Math.round(confFake * 100),
      verdict_text: confFake >= 0.5 ? "Likely False" : "Likely True",
      model_shape: "baseline",
      primary_source: null, // no sources from baseline
      url: location.href,
      title: document.title,
      at: Date.now()
    };
  }

  // Verification-system style output
  const probs = raw?.probabilities || {};
  const pFalse = clamp01(Number(probs.false ?? raw?.confidence_fake ?? 0));
  const pTrue  = clamp01(Number(probs.true  ?? raw?.confidence_true ?? (1 - pFalse)));

  const predLabel = inferPredictedLabel(raw?.verdict, pFalse); // 1 fake, 0 true
  const primary = pickPrimarySource(raw, predLabel);

  return {
    input: raw?.input ?? inputText,
    predicted_label: predLabel,
    confidence_true: pTrue,
    confidence_fake: pFalse,
    percent_false: Math.round(pFalse * 100),
    verdict_text: verdictTextFrom(predLabel, raw?.verdict),
    model_shape: "verification_system",
    primary_source: primary, // {source, detail?}
    url: location.href,
    title: document.title,
    at: Date.now(),
    raw 
  };
}

function clamp01(x) {
  if (Number.isNaN(x)) return 0;
  return Math.max(0, Math.min(1, x));
}

function inferPredictedLabel(verdict, pFalse) {
  if (typeof verdict === "string") {
    const v = verdict.toLowerCase();
    if (v.includes("likely_false")) return 1;
    if (v.includes("likely true") || v.includes("likely_true")) return 0;
  }
  return pFalse >= 0.5 ? 1 : 0;
}

function verdictTextFrom(label, verdictStr) {
  if (typeof verdictStr === "string" && verdictStr.trim()) {
    if (verdictStr.includes("likely_false")) return "Likely False";
    if (verdictStr.includes("likely_true")) return "Likely True";
  }
  return label === 1 ? "Likely False" : "Likely True";
}

/** Choose the best source to show (prefers arrays aligned with the prediction; falls back to nearest). */
function pickPrimarySource(result, predLabel) {
  // Prefer aligned supporting arrays
  let pool = [];
  if (predLabel === 1 && Array.isArray(result?.supporting_sources_false) && result.supporting_sources_false.length) {
    pool = result.supporting_sources_false;
  } else if (predLabel === 0 && Array.isArray(result?.supporting_sources_true) && result.supporting_sources_true.length) {
    pool = result.supporting_sources_true;
  } else if (Array.isArray(result?.nearest_sources_considered) && result.nearest_sources_considered.length) {
    pool = result.nearest_sources_considered;
  }

  if (!pool.length) return null;

  // If scores exist (entailment/contradiction), pick the max; else pick most frequent by source string.
  let scored = pool
    .map(item => ({
      source: item.source || null,
      score: Number(item.entailment ?? item.contradiction ?? item.similarity ?? 0),
      detail: item
    }))
    .filter(x => !!x.source);

  if (!scored.length) return null;

  // Try best score first
  scored.sort((a, b) => b.score - a.score);
  const bestByScore = scored[0];

  // Also compute mode by source
  const counts = new Map();
  for (const x of scored) counts.set(x.source, (counts.get(x.source) || 0) + 1);
  let modeSource = bestByScore.source, modeCount = -1;
  for (const [s, c] of counts) {
    if (c > modeCount) { modeSource = s; modeCount = c; }
  }

  // Prefer “most used”; keep best score detail for tooltip
  return { source: modeSource, count: modeCount, best: bestByScore.detail || null };
}

function showToast(text) {
  const toast = document.createElement("div");
  toast.textContent = text;
  Object.assign(toast.style, {
    position: "fixed",
    left: "16px",
    bottom: "16px",
    zIndex: 2147483647,
    background: "#fff",
    border: "1px solid #ddd",
    borderRadius: "8px",
    padding: "10px 12px",
    boxShadow: "0 4px 14px rgba(0,0,0,0.12)",
    font: "14px/1.3 system-ui, -apple-system, Segoe UI, Roboto, sans-serif"
  });
  document.body.appendChild(toast);
  setTimeout(() => toast.remove(), 3500);
}
